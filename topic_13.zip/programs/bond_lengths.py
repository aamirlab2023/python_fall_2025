import math as m

f = open("./datasets/coordinates.txt", "r")
lines = f.readlines()
f.close()

symbols = []
x = []
y = []
z = []
for line in lines:
    line = line.split()
    symbols.append(line[0])
    x.append(float(line[1]))
    y.append(float(line[2]))
    z.append(float(line[3]))

bond_lengths = []
for counter in range(1, 5):
    bond_lengths.append(m.sqrt((x[counter] - x[0])**2 + (y[counter] - y[0])**2 + (z[counter] - z[0])**2))

f = open("./datasets/bond_lengths.txt", "w")
counter = 1
for i in range(len(bond_lengths)):
    f.write(f"Bond Length {counter:d}: ")
    f.write(f"{bond_lengths[counter - 1]:.2f}")
    f.write("\n")
    counter += 1
f.close()