single_str = "Details"
list_str = ["Aamir", "Instructor", "Programming"]
f = open("computed.txt", "w")
f.write(single_str)
f.writelines(list_str)
f.close()

single_str = "Details"
list_str = ["Aamir", "Instructor", "Programming"]
f = open("computed.txt", "a")
f.write(single_str + "\n")
f.write("\n")
for i in list_str:
    f.writelines(i + " ")
f.close()