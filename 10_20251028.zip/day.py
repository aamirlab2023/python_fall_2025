#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Programmer: Aamir Alaud Din, PhD
# Program: day.py
# Date: 2021.10.20

# Objective(s):
#  To identify a day of the week.

day = input("Enter the day: ")
day = day.lower()

if day == "saturday":
	print("\nThis is weekend.")
	print("Tomorrow is off day. Enjoy! :)")
elif day == "sunday":
	print("\nThis is holiday.")
	print("Tomorrow is a working day. :(")
elif day == "monday" or day == "tuesday" or day == "wednesday" or day == "thursday" or day == "friday":
	print("\nThis is a week day.")
	print("I am busy. :|")
else:
	print("\nWrong data provided.")
	print("I know only days.")
	print("What you provided to me is not a day.")
	print("I am a program, I'm not wrong. You're wrong.")
	print("Please provide me a day.")
