a = 1.35E-5
b = -3.25E-3
c = 6.91
m = 1
t_ref = 25
temps = [75, 79, 87, 88, 94, 100]
print("Temperature    Specific Heat    Enthalpy")
print("===========    =============    ===========")
for temp in temps:
    cp = a*temp**2 + b*temp + c
    h = m*cp*(temp - t_ref)
    print(f"{temp:<15.2f}{cp:<16.4E}{h:11.4E}")
