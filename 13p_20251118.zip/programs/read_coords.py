f = open("./datasets/coordinates.txt", "r")
lines = f.readlines()
f.close()

print(lines)

symbol = []
x = []
y = []
z = []
for line in lines:
    line = line.split()
    symbol.append(line[0])
    x.append(float(line[1]))
    y.append(float(line[2]))
    z.append(float(line[3]))

print(symbol)
print(x)
print(y)
print(z)