<style>
  .line-container {
    position: relative;
    margin-left: 0px; /* spacing from other elements */
    margin-right: 0px;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .horizontal-line {
    height: 2px; /* Line thickness */
    background-color: blue; /* Line color */
    width: 100%; /* Full width line */
  }
  .top-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    top: 100%; /* Position just below the line */
    left: 0; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .bottom-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    bottom: 100%; /* Position just below the line */
    right: 0%; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
</style>
<style>
  .definition-box {
    width: 100%;
    border: 2px solid navy;
    border-radius: 10px;
    overflow: hidden;
  }
  .definition-header {
    background-color: navy;
    color: white;
    padding: 10px;
    font-size: 52px;
    font-weight: bold;
  }
  .definition-body {
    background-color: white;
    color: navy;
    padding: 15px;
    line-height: 2.0;
    font-size: 52px;
    text-align: justify;
  }
</style>

<div style="background-color: black; padding: 20px; border-radius: 40px;">
  <h1 style="font-size: 82px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">🖥️ Fundamentals of Programming</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">📝 Sequence Data Type in Python</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: red;">🎓 Dr. Aamir Alaud Din</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: green;">🗓️ August 25, 2025</h1>
</div>
<br><br><br>

<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">Contents</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="1">
    <li>Recap</li>
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>Lists</li>
    <li>Range and Tuple</li>
    <li>Strings</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">1. Recap</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In unformatted printing, variable is directly passed to the <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">print()</code> function as input argument.</li>
    <li>In formatted printing f-string printing is used.</li>
    <li>In f-string, the place holder is the location of printing data.</li>
    <li>In f-string printing, the data types inside place holder are represented by the following characters.</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ol style="1">
        <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">d</code> is used to represent integers.</li>
        <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">f</code> is used to represent folating point numbers.</li>
        <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">e</code> is used to represent data in scientific notation.</li>
        <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">s</code> is used to represent strings.</li>
      </ol>
    </div>
    <li>The printing alignment in reserved spaces is controlled with following three symbols.</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ol style="1">
        <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;"><</code> is used for left aligned printing.</li>
        <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">></code> is used for right aligned printing.</li>
        <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">^</code> is used for centered printing.</li>
      </ol>
    </div>
    <li>Printing of mixed data types requires concatenation with knowledge of escape characters.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">2. Objectives</h2>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">After <span style="color: green;">taking this lecture</span> and <span style="color: red;">studying</span>, you should be able to:</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Define and use lists in Python.</li>
    <li>Define and use range function.</li>
    <li>Define and use tuple function.</li>
    <li>Define and use string functions.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">3. The Why Section</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>So far, we used only single numbers assigned to variables.</li>
    <li>Suppose, we perform an experiment in the laboratory and record the amount of a chemical X consumed in a chemical reaction at any time t.</li>
    <li>If we record seven values of time and amount of X consumed, these will be forteen values.</li>
    <li>Instead of defining forteen variables, we define only two variables and assign time data to one variable and amount of X consumed to the other variable.</li>
    <li>One reason of studying this topic is to learn how to assign several values to a single variable and how to use them.</li>
    <li>This is quite possible that while writing programs, one or more values assigned to a variable may change.</li>
    <li>How to assign values to a variable such that the assignment is unchanged.</li>
    <li>The second reason of studying this topic is to learn what to do so that a collection of data can't be changed e.g., bank account numbers of different people.</li>
    <li>If we want to generate a sequence of numbers like from 1 to 100 with a difference of 2, we can type it.</li>
    <li>What if we have to generate a sequence from 1 to 1,000,000,000?</li>
    <li>The third reason of studying this topic is to learn how to generate sequence of numbers.</li>
    <li>It may come to mind that programming is for the compuations and therefore, processing of text/string data is not important.</li>
    <li>Natural language processing and the related fields require heavy text processing.</li>
    <li>Therefore, the last reason of studying this topic is to learn the processing of text.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">4. Lists</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Now, we start learning how to assign several values to a single vriable.</li>
    <li>Such an assignment is called list.</li>
  </ul>
</div>

<div class="definition-box">
  <div class="definition-header">Definition: List</div>
  <div class="definition-body">
    A list is a collection of data/variables enclosed within square brackets and the data/variables in the list are called elements of the list. The elements are separated by commas and indices are assigned to list elements by python. The list elements may be of same or different data types.
  </div>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The lists must be assinged to a variable.</li>
    <li>An example to initialize a list is show below.</li>
  </ul>
</div>

<span style="font-size: 45px;">

```python
sci_consts = ['light_speed', 299792458, 'real_gas_const', 0.08205, 'Scientific Constants']
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>List elements can be accessed by using indices of elements.</li>
    <li>First element of list has index 0, the second element has index 1, and so on.</li>
    <li>This indexing starting from 0 for the first element is known as forward indexing.</li>
    <li>Another indexing, known as the backward indexing, has an index of -1 for the last element, index of -2 for the second last element and so on.</li>
    <li>This forward and backward indexing is shown in figure 1 below.</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0501.png" width="100%" alt="indexing"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 1.</strong> Forward and backward indexing in lists.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We can print the complete list by the command <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-size: 45px; font-family: monospace;">print(sci_consts)</code> to the Python interpreter.</li>
    <li>Indices are very helpful in slicing lists which is extracting some part of the list.</li>
    <li>If we want to get the numerical value of the speed of light i.e., 299792458 with index value of 1, we will use its index to get it as shown below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
sci_consts = ["light_speed", 299792458, "Real_gas_const", 0.08206, "Scientific Constants"]
c = sci_consts[1]
print(c)
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>So, to call a list element we use indices within square brackets just after variable name.</li>
    <li>The result of the above Python statements are given below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```c#
299792458
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Notice that first element has the index 0, the second element has index 1, and so on.</li>
    <li>Index number of an element in a list is one less than its actual position in the list.</li>
    <li>In order to extract the third and fourth elements from <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">sci_consts</code>, we use the following statements.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
required = sci_consts[2:4]
print(required)
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above short python program is the list as shown below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```c#
['Real_gas_const', 0.08206]
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The index notation i.e., <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">[2:4]</code>instructs Python interpreter to print a sublist from sci_consts list the elements starting from index 2 through 3.</li>
    <li>Although the last index 4 is used in call, but Python automatically drops the last index called.</li>
    <li>The same output can also be obtained using backward indexing as shown below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
print(sci_consts[-3:-1])
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The commands <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">print(sci_consts)</code>, <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">print(sci_conts[:])</code>, or <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">print(sci_const[0:])</code> will print the complete list.</li>
    <li>List methods also help to perform several tasks.</li>
    <li>For example, we can replace the value 7, appearing first in the list <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">[1, 2, 7, 5, 6, 7, 8, 9]</code>, with 3 with the following Python statements.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
x = [1, 2, 7, 5, 6, 7, 8, 9]
x[2] = 3
print(x)
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Now, if we want to insert the element 4 at index position 3 in the modified list <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">[1, 2, 3, 5, 6, 7, 8, 9]</code>, we can do it as follows.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
x.insert(3, 4)
print(x)
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above short program is as follows.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```c#
[1, 2, 3, 4, 5, 6, 7, 8, 9]
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We can append an element to the list using <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">append</code> method as shown below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
x.append(10)
print(x)
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above two statements is given below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```c#
[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>There are also other list methods for different operations.</li>
    <li>Students are advised to find and use all the list methods in Python.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">5. Range and Tuple</h2>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">5.1 Range</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>A list may hold different data types and without any sequence.</li>
    <li>However if we want to generate sequence of integers, we can use the range function.</li>
    <li>At least 1 and maximum 3 input arguments can be passed to the <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">range</code> function.</li>
    <li>The following table explains the output of range function with varying number of input arguments.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0">

|Number of Input Arguments|Function Call|Output|
|:---|:---|:---|
|1|range(n)|Integers from 0 throught n-1 are generated|
|2|range(m, n)|Integers from m through n-1 are generated|
|3|range(m, n, k)|Integers from m through n-1 with a difference of k between any two adjacent integers are generated|

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The elements of range are immutable i.e., elements of range can't be reassigned.</li>
    <li>The elements generated by range function can be accessed by indexing and slicing, however, the output will again be a range so that the output still remains immutable.</li>
    <li>In order the visualize the elements of range function, we use the syntax <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">print(*range(n))</code>.</li>
    <li>Some examples of range function are given below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
x = range(6)
print(*x)
x = range(6, 11)
print(*x)
x = range(1, 21, 3)
print(*x)
x = range(1, 22, 3)
print(*x)
print(*x[2])
print(*x[2:])
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of above code is as follows.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```c#
0 1 2 3 4 5
6 7 8 9 10
1 4 7 10 13 16 19
1 4 7 10 13 16 19
7
7 10 13 16 19
```

</span>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">5.2 Tuple</h3>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Tuple</div>
  <div class="definition-body">
    A tuple is a collection of immutable data/variables enclosed within parentheses and the data/variables in tuple are called elements of the tuple. The elements are separated by commas and indices are assigned to tuple elements by Python. The tuple elements may be of same or different data types.
  </div>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Rules of tuple indexing and slicing are the same as those of lists, however, the output of indexing and slicing is again a tuple making it immutable.</li>
    <li>Tuple methods are less than list methods.</li>
    <li>Students are advised to find list methods <a href="https://www.geeksforgeeks.org/python/list-methods-python/" target="_blank">here</a> and practice them.</li>
    <li>Similarly, range methods are also available and students are advised to find and practice them.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">6. Strings</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>String is text data type to which Python recognizes by its closure within single or double quotes.</li>
    <li>The rules for indexing and slicing of strings are the same as those of lists.</li>
    <li>The following lines of Python code are self explanatory.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
fun_str = "Doing Python is a fun."
print(fun_str[6:12])
print("If you don't study and practice Python.")
new_str = fun_str[:index] + 'g' + fun_str[index+1:]
print(new_str)
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of above Python lines is given below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```c#
Doing Python is fun.
If you don't study and practice Python.
Doing Python is gun.
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The binary operations <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">+</code> and <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">*</code> are applicable on strings but their action is different.</li>
    <li>The operation <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">+</code> joins two strings.</li>
    <li>The operation <code style="background-color: #f5f2f0; padding: 2px 4px; font-size: 45px; border-radius: 4px; font-family: monospace;">*</code> replicates the string.</li>
    <li>Below are the relevant examples.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```python
first = "Aamir"
middle = "Alaud"
last = "Din"
print(first + " " + middle + " " + last)
print(5*first)
```

</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of above statments is shown below.</li>
  </ul>
</div>

<br>
<span style="font-size: 45px;">

```c#
Aamir Alaud Din
AamirAamirAamirAamirAamir
```

</span>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">7. Summary</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>A list is a collection of data/variables enclosed within square brackets and the data/variables in the list are called elements of the list. The elements are separated by commas and indices are assigned to list elements by python. The list elements may be of same or different data types.</li>
    <li>List elements are accessed by indexing and slicing.</li>
    <li>Range function in Python generates a sequence of integers.</li>
    <li>1 to 3 input arguments can be passed to range function.</li>
    <li>A tuple is a collection of immutable data/variables enclosed within parentheses and the data/variables in tuple are called elements of the tuple. The elements are separated by commas and indices are assigned to tuple elements by Python. The tuple elements may be of same or different data types.</li>
    <li>A string is text data whose rules for slicing and indexing are the same as those for lists.</li>
    <li>List, range, tuple, and string methods help to perform different operations related to them.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">8. Exercises</h2>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 1</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Define a list of mixed data types. Use all the list methods on the list and understand all the list methods.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 2</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Define three ranges of integers with one, two, and three input arguments passed to range function. Use all the range methods on three ranges generated and understand all the range methods.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 3</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Define a tupe of mixed data types. Use all the tuple methods on the tuple and understand all the tuple methods.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 4</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Define a string. Use all the string methods on the string and understand all the string methods.</p>
