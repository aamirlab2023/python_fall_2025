<style>
  .line-container {
    position: relative;
    margin-left: 0px; /* spacing from other elements */
    margin-right: 0px;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .horizontal-line {
    height: 2px; /* Line thickness */
    background-color: blue; /* Line color */
    width: 100%; /* Full width line */
  }
  .top-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    top: 100%; /* Position just below the line */
    left: 0; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .bottom-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    bottom: 100%; /* Position just below the line */
    right: 0%; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
</style>
<style>
.definition-box {
width: 100%;
border: 2px solid navy;
border-radius: 5px;
overflow: hidden;
}
.definition-header {
background-color: navy;
color: white;
padding: 10px;
font-weight: bold;
}
.definition-body {
background-color: white;
color: navy;
padding: 15px;
line-height: 2.0;
text-align: justify;
}
</style>

<div style="background-color: black; padding: 20px; border-radius: 10px;">
  <h1 style="color: orange; text-align: center; line-height: 2.0;">🖥️ Fundamentals of Programming</h1>
  <h1 style="color: orange; text-align: center; line-height: 2.0;">📝 Printing Data in Python</h1>
  <h1 style="color: red; text-align: center; line-height: 2.0;">🎓 Dr. Aamir Alaud Din</h1>
  <h1 style="color: green; text-align: center; line-height: 2.0;">🗓️ August 26, 2025</h1>
</div>
<br>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0; padding-left: 10px; font-weight: bold;">Contents</h2>
<div style="font-size: 24px; line-height: 2.0; padding-left: 40px;">
  <ol type="1">
    <li>Recap</li>
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>Printing Integers</li>
    <li>Printing Floating Point Numbers</li>
    <li>Printing in Scientific Notation</li>
    <li>Printing Strings</li>
    <li>Concatenation</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px; font-weight: bold;">2. Objectives</h2>
<p style="line-height: 2.0; text-align: justify;">After <span style="color: green;">taking this lecture</span> and <span style="color: red;">studying</span>, you should be able to:</p>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Print numeric data types in Python.</li>
    <li>Print numeric data types with control over data attributes.</li>
    <li>Concatenate the printing of different data types simultaneously.</li>
  </ul>
</div>

<h2 style="color: black; font-weight: bold; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">3. The Why Section</h2>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Consider an integer data type assigned to variable <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">x</code> and its printing as shown below.</li>
  </ul>
</div>

```python
x = 5
print(x)
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above program is shown below.</li>
  </ul>
</div>

```
5
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Is it possible to print <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">x = 5</code> with 5, 8, or any desired number of padded zeros?</li>
    <li>Now, consider the floating point data assigned to variable <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">y</code> and its printing as shown below.</li>
  </ul>
</div>

```python
y = 1.41
print(y)
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above program is shown below.</li>
  </ul>
</div>

```
1.41
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Can we print <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">y = 1.41</code> upto 4, 7, or 10 decimal places?</li>
    <li>Consider the following output of some program</li>
  </ul>
</div>

```
C-C Bonds: 6
C-C Bond Length: 1.40
C-H Bonds: 6
C-H Bond Length: 1.093
Benzene has 12 bonds and average bond length is 1.2465
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The above output has <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">int</code>, <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">float</code>, and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">str</code> data types.</li>
    <li>How can we print such a mixed data type simultaneously?</li>
    <li>The reason of studying this topic is not only to print data, but to learn printing with full control over required printing (individual and mixed data types).</li>
  </ul>
</div>

<h2 style="color: black; font-weight: bold; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">4. Printing Integers</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li>Consider the following Python statement of assigning an integer to the variable <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">n_bonds</code>.</li>
    <li>Python's <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">print()</code> function is used to print data to standard output display device or LCD.</li>
    <li>We study different types of printing now.</li>
  </ul>
</div>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">4.1 Unformatted Printing</h3>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The variable name is passed to the <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">print()</code> function as shown below.</li>
  </ul>
</div>

```python
n_bonds = 6
print(n_bonds)
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the program is shown below.</li>
  </ul>
</div>

```
6
```

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">4.2 Formatted Printing</h3>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In formatted printing, we have control over printing.</li>
    <li>For formatted printing f-string printing is used.</li>
  </ul>
</div>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">4.2.1 Unformatted Printing with F-string</h4>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We print <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">n_bonds</code> with f-string as shown below.</li>
  </ul>
</div>

```python
n_bonds = 6
print(f"{n_bonds}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above program is as follows.</li>
  </ul>
</div>

```
6
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In the above program <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">{}</code> is called the placeholder and it will become more clear in the subtopic of concatenation.</li>
  </ul>
</div>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">4.2.2 Informing Interpreter the Data Type</h4>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We can also inform the interpreter that the data type is integer with letter <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">d</code>, called the format specifier, inside the place holder.</li>
    <li>Since variable is also written inside the place holder, so, variable name and format specifier must be separated by the color operator like <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">{variable:format}</code>.</li>
    <li>The printing statement is given below.</li>
  </ul>
</div>

```python
print(f"{n_bonds:d}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output will still be <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">6</code>.</li>
  </ul>
</div>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">4.2.3 Reserving Spaces with Right Alignment</h4>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>If we want to print <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">n_bonds</code> in 20 reserved spaces and aligned to right, we type <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">>20</code> just after the separator i.e., just after the colon operator.</li>
    <li>The symbol <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">></code> tell interpreter that the printing is right aligned and the number <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">20</code> informs that the variable must be printed within 20 blank reserved spaces.</li>
    <li>This type of priting is shown below.</li>
  </ul>
</div>

```python
print(f"{n_bonds:>20d}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above program is shown below.</li>
  </ul>
</div>

```c#
                   6
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The idea of reserved spaces and printing in these reserved spaces is shown in figure 1.</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0401.png" width="100%" alt="right_integer"><br>
  <figcaption style="text-align: center;"><strong>Figure 1.</strong> Right aligned printing of integer within 20 reserved spaces.</figcaption>
</figure><br>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">4.2.4 Reserved Spaces with Left Alignment</h4>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The printing is exactly the same as right aligned printing with a minor change that the <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">></code> symbol for right aligned printing is replaced with <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;"><</code> symbol for left aligned printing.</li>
    <li>This printing is shown in the program below.</li>
  </ul>
</div>

```python
print(f"{n_bonds:<20d}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of this program is shown below.</li>
  </ul>
</div>

```c#
6                   
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>If no alignment symbol is used, the Python prints right aligned by default.</li>
  </ul>
</div>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">4.2.6 Middle Aligned Printing in Reserved Blank Spaces</h4>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>For centred printing or middle aligned printing, the alignment symbol <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">^</code> is used.</li>
    <li>The program for such a printing is shown below.</li>
  </ul>
</div>

```python
print(f"{n_bonds:^20d}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above Python code is shown below.</li>
  </ul>
</div>

```c#
         6          
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>There are 9 blank spaces before 6 and 10 blank spaces after 6.</li>
    <li>The reason of one less blank space on left than on right will be clear when we study the magic fonts in this lecture.</li>
  </ul>
</div>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">Printing with Left Padded Zeros</h4>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Suppose we want to print 12 left padded zeros before the number 6, we can do it with the following Python statement.</li>
  </ul>
</div>

```python
print(f"{n_bonds:013d}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output will contain 12 left padded zeros with the integer 6 on the 13<sup>th</sup> place.</li>
  </ul>
</div>

```c#
0000000000006
```

<h2 style="color: black; font-weight: bold; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">5. Printing Floating Point Numbers</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li>Suppose we want to print the number 1.431 which is assigned to variable <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">bond_length</code>.</li>
    <li>If we use the unformatted printing by passing <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">bond_length</code> to the <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">print()</code> function or we use f-string printing with the use of only variable name inside the place holder, the Python prints the number as it is.</li>
    <li>The format specifier for floating point numbers is <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">f</code>.</li>
    <li>If format specifier is used, Python prints the floating point number to 6 decimal places by default.</li>
    <li>The above discussion can be summarized in the following three lines of Python code.</li>
  </ul>
</div>

```python
bond_length = 1.431
print(bond_length)
print(f"{bond_length}")
print(f"{bond_length:f}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above three Python statement are shown below.</li>
  </ul>
</div>

```c#
1.431
1.431
1.431000
```

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">5.1 Controlling Decimal and Reserved Spaces</h3>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>If <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">.x</code> is used just after the separator, the number will be printed to <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">x</code> decimal places.</li>
    <li>For example, the printing of number to two decimal places can be accomplished with the following Python statement.</li>
  </ul>
</div>

```python
print(f"{bond_length:.2f}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above Python statement is as follows.</li>
  </ul>
</div>

```c#
1.43
```

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">5.2 Controlling Decimal Places and Alignment in Reserved Spaces</h3>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The alignment symbols for alignment are exactly the same as discussed in section 4 of this topic.</li>
    <li>The number of reserved spaces are specified just after the alignment symbol, if either of the alignment symbol is used or just after colon operator if no alignment symbol is used.</li>
    <li>If no alignment symbol is used, Python aligns the printing to right side by default.</li>
    <li>Below we give examples of left, right, and middle aligned printing to 5 decimal places in 15 reserved spaces.</li>
    <li>We will use the value of $\pi$ i.e., 3.141592653589793 assigned to variable <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">pi</code>.</li>
  </ul>
</div>

```python
pi = 3.141592653589793
print(f"{pi:<15.5f}")
print(f"{pi:>15.5f}")
print(f"{pi:^15.5f}")
print(f"{pi:15.5f}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above Python statements are given below.</li>
  </ul>
</div>

```c#
3.14159        
        3.14159
    3.14159    
        3.14159
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The terminologies learnt so far are scattered.</li>
    <li>We use figures below which not only summrize the integers and floats printing but also summarizes the terminologies used.</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0402.png" width="100%" alt="print_01"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 2.</strong> Printing of floating point number to four places of decimal and aligned left in 20 reserved spaces.</figcaption>
</figure><br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0403.png" width="100%" alt="print_02"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 3.</strong> The <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">print()</code> function in printing floating point number.</figcaption>
</figure><br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0404.png" width="100%" alt="print_03"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 4.</strong> Use of f-string in f-string printing.</figcaption>
</figure><br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0405.png" width="100%" alt="print_04"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 5.</strong> Use of place holder in f-string printing.</figcaption>
</figure><br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0406.png" width="100%" alt="print_05"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 6.</strong> Use of variable names inside place holder of f-string.</figcaption>
</figure><br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0407.png" width="100%" alt="print_06"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 7.</strong> Use of format specifier inside place holder in f-string printing.</figcaption>
</figure><br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0408.png" width="100%" alt="print_07"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 8.</strong> Use of alignment symbol inside place holder in f-string printing.</figcaption>
</figure><br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0409.png" width="100%" alt="print_08"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 9.</strong> Reserving number of blank spaces inside place holder in f-string printing for printing of variable.</figcaption>
</figure><br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0410.png" width="100%" alt="print_09"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 10.</strong> Fixation of the number of decimal of a floating point number inside place holder in f-string printing.</figcaption>
</figure><br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0411.png" width="100%" alt="print_10"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 11.</strong> Use of colon operator for variable and format separation inside place holder in f-string printing.</figcaption>
</figure><br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0412.png" width="100%" alt="print_11"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 12.</strong> Complete summary of printing with f-string.</figcaption>
</figure><br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0413.png" width="100%" alt="print_12"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 13.</strong> Printing alignment in fixed number of spaces.</figcaption>
</figure><br>

<h2 style="color: black; font-weight: bold; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">6. Printing in Scientific Notation</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li>Both, integers and floats, can be printed in scientific notation.</li>
    <li>Sometimes, it is required to print integer or floating point data in scientific notation.</li>
    <li>Avogadro's number is 602,214,076,000,000,000,000,000 represented by $N_A$.</li>
    <li>In order the print it in scientific notation, everything is the same as in the case of floating point number.</li>
    <li>The only difference is the use of format specifier which is <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">e</code> or <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">E</code>.</li>
    <li>The usual scientific presentation of Avogadro's number using Python program is given below.</li>
  </ul>
</div>

```python
na = 602214076000000000000000
print(f"{na:18.3E}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of this program is as shown below.</li>
  </ul>
</div>

```c#
6.022E+23
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We notice that reading large number like Avogadro's number in computer programs may create confusion because thousand separtion commas are not allowed within numeric data in Python.</li>
    <li>However, Python allows the use of underscores in place of commas for ease of program readability in integers and floats.</li>
    <li>So, the variable assignment <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">na = 602_214_076_000_000_000_000_000</code> is exactly the same as <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">na = 602214076000000000000000</code> which is without underscores.</li>
    <li>The print output of both assignments is always without underscores as shown below.</li>
  </ul>
</div>

```c#
602214076000000000000000
```

<h2 style="color: black; font-weight: bold; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">7. Printing Strings</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li>String can be passed either directly to the <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">print()</code> function or the variable containing the string can be passed to the <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">print()</code> function.</li>
    <li>The following print statements show printing of string by passing string directly and passing the variable containing string to the <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">print()</code> function.</li>
  </ul>
</div>

```python
print("Computer programming is logical.")
prog_state = "Computer programming is logical."
print(f"{prog_state}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of the above statements is the same which is shown below.</li>
  </ul>
</div>

```c#
Computer programming is logical.
Computer programming is logical.
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The format specifier for printing of strings is <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">s</code>.</li>
    <li>The printing of the above variable in 50 reserved spaces with different alignments is shown in following Python print statements and are self explanatory.</li>
  </ul>
</div>

```python
print(f"{prog_state:<50s}")
print(f"{prog_state:>50s}")
print(f"{prog_state:^50s}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The output of these lines is shown below.</li>
  </ul>
</div>

```c#
Computer programming is logical.                  
                  Computer programming is logical.
         Computer programming is logical.         
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Python overrides the user input number of blank spaces if length of string is longer than the number of reserved spaces provided by the use.</li>
    <li>For example, if we try to print <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">prog_state</code> in 10 reserved spaces, Python will automatically reserve 32 spaces for the string and will print it.</li>
    <li>More controls of printing strings will be included when we will study strings in detail.</li>
  </ul>
</div>

<h2 style="color: black; font-weight: bold; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">8. Concatenation</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li>So far, we discussed the printing of integers, floating point numbers, and strings individually.</li>
    <li>But, how to print if we have a mixture of data types?</li>
  </ul>
</div>

<div class="definition-box">
  <div class="definition-header">Definition: Concatenation</div>
  <div class="definition-body">
    The art of printing mixed data types is called concatenation.
  </div>
</div>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The place holders inside the f-string decide the location where the variable is to be printed.</li>
    <li>Suppose, we have to variables which are <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">cc_bonds</code> and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">cc_bond_length</code> to which the <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">int</code> and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">float</code> data types are assigned as shown below.</li>
  </ul>
</div>

```python
cc_bonds = 6
cc_bond_length = 0.14
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Varities of print statments can be used to print <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">There are 6 C-C bonds and bond length of each C-C bond is 0.1400 nm.</code></li>
    <li>We show few varities to do the job.</li>
  </ul>
</div>

```python
cc_bonds = 6
cc_bond_length = 0.14
print(f"There are {cc_bonds:d} C-C bonds and bond length of each C-C bond is {cc_bond_length:.4f} nm.")
print(f"There are{cc_bonds:2d} C-C bonds and bond length of each C-C bond is{cc_bond_length:7.4f} nm.")
print(f"There are{cc_bonds:^3d}C-C bonds and bond length of each C-C bond is{cc_bond_length:^8.4f}nm.")
str1 = "There are"
str2 = "C-C bonds and bond length of each C-C bond is"
str3 = "nm."
print(f"{str1:<10s}{cc_bonds:<2d}{str2:<46s}{cc_bond_length:<7.4f}{str3:<4s}")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Suppose, we want to print the following statments.</li>
  </ul>
</div>

```c#
There are 6 C-C bonds.
The bond lenght of each C-C bond is 0.1400 nm.
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The following two different statement do the job.</li>
  </ul>
</div>

```python
print(f"There are {cc_bonds:d} C-C bonds.")
print(f"The bond length of each C-C bond is {cc_bond_length:.4f} nm.")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Another version which does the same job is shown below.</li>
  </ul>
</div>

```python
print(f"There are {cc_bonds:d} C-C bonds.\nThe bond length of each C-C bond is {cc_bond_length:.4f} nm.")
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The characters <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">\n</code> is called the escape character and is called the line feed i.e., new line.</li>
    <li>Similarly, there are other escape characters which do different jobs.</li>
  </ul>
</div>

<h2 style="color: black; font-weight: bold; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">9. Summary</h2>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In unformatted printing, variable is directly passed to the <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">print()</code> function as input argument.</li>
    <li>In formatted printing f-string printing is used.</li>
    <li>In f-string, the place holder is the location of printing data.</li>
    <li>In f-string printing, the data types inside place holder are represented by the following characters.</li>
    <ol style="1">
      <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">d</code> is used to represent integers.</li>
      <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">f</code> is used to represent folating point numbers.</li>
      <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">e</code> is used to represent data in scientific notation.</li>
      <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">s</code> is used to represent strings.</li>
    </ol>
    <li>The printing alignment in reserved spaces is controlled with following three symbols.</li>
    <ol style="1">
      <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;"><</code> is used for left aligned printing.</li>
      <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">></code> is used for right aligned printing.</li>
      <li>The character <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">^</code> is used for centered printing.</li>
    </ol>
    <li>Printing of mixed data types requires concatenation with knowledge of escape characters.</li>
  </ul>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; font-weight: bold; padding-left: 10px;">10. Exercises</h2>
<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Exercise 1</h3>
<p style="line-height: 2.0; text-align: justify;">Print the following variables using f-string.</p>

|Variable|Data Type|Reserved Spaces|Alignment|Notation|Decimal Places|
|:---|:---|:---|:---|:---|:---|
|```c=299792458```|```int```|20|Right|N/A|N/A|
|```name="Aamir Alaud Din"```|```str```|22|Middle|N/A|N/A|
|```c=299792458```|```int```|20|Right|Decimal|2|
|```na=6.022E+23```|```float```|10|Left|Scientific|4|
|```me=9.109e-31```|```float```|15|Middle|Scientific|2|
|```me=9.109E-31```|```float```|40|Left|Decimal|34|
|```R=0.08206```|```float```|8|Left|Scientific|2|
|```kb=1.380649E-23```|```float```|20|Right|Scientific|4|
|```kb=1.380649E-23```|```float```|30|Middle|Scientific|5|
|```kb=1.380649E-23```|```float```|29|Left|Decimal|29|

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Exercise 2</h3>
<p style="line-height: 2.0; text-align: justify;">Python escape characters are used to format f-string and a list of escape characters with examples is given <a href="https://www.geeksforgeeks.org/python/python-escape-characters/" target="_blank">here</a>. You are required to use each escape sequence in your own preferred string like the one given below.</p>

```c#
test="My name is Aamir Alaud Din. I teach Fundamentals of Programming at SCEE (IESE)."
```

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Exercise 3</h3>
<p style="line-height: 2.0; text-align: justify;">Consider the following statement</p>

```c#
milk = "We are 6 members and we consume 2.25 L milk daily."
```

Assign variables and use them to print the above string as shown below.

```python
str1 = "We are"
members = 6
str1 = "members and we consume"
usage = 2.25
str3 = "L milk daily."
print(f"{str1:<7s}{members:d}{str2:^24s}{usage:<5.2f}{str3}")
```

<p style="line-height: 2.0; text-align: justify;">Print the following statements using f-string just like the example given above.</p>

<div style="line-height: 2.0; text-align: justify;">
  <ol type="a">
    <li>In a sodium atom, there are $11$ electrons and the mass of one electron is $9.109 \times 10^{-31}\;kg$.</li>
    <li>The speed of light in vacuum is approximately $3.00 \times 10^{8}\;m/s$, a constant value in physics.</li>
    <li>A single water molecule (H<sub>2</sub>O) contains $2$ hydrogen atoms and $1$ oxygen atom. Atomic masses of hydrogen and oxygen are $1.008$ and $15.999$ amu.</li>
    <li>The universal gas constant R equals $8.314\;J/(mol·K)$.</li>
    <li>The Avogadro number is $6.022 \times 10^{23}\;mol^{-1}$, representing the number of entities in $1$ mole.</li>
    <li>The freezing point of water is $0\;^oC$ or $273.15\;K$ under standard atmospheric pressure.</li>
    <li>The charge of a proton is $+1.602 \times 10^{-19}\;C$, while the charge of an electron is negative of this value.</li>
    <li>The gravitational constant G is $6.674 \times 10^{-11} N·m^2/kg^2$.</li>
    <li>The Planck constant h is $6.626 \times 10^{-34}\;J·s$, used in quantum mechanics.</li>
    <li>Carbon-12 has an atomic mass of exactly $12\;u$, by definition of the unified atomic mass unit and that of hydrogen is $1.008\;u$.</li>
  </ol>
</div>

<h4 style="color: red; font-weight: bold; line-height: 2.0;">Note:</h4>

<div style="line-height: 2.0; text-align: justify; color: red;">
  <ul style="list-style-type:disc">
    <li>There must not be more than one space between any two adjacent words and numbers.</li>
    <li>If your output is not correct in the first go, first understand the problem and then modify the print statement accordingly so that your desired output is correct in the second go.</li>
    <li>Understand all the exercises logically, because, similar exercises may be part of quizzes, MSE, and ESE.</li>
    <li>Deadline is same day class in next week.</li>
  </ul>
</div>