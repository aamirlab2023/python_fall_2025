<link href="https://cdn.jsdelivr.net/npm/prismjs/themes/prism.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/prismjs/prism.js"></script>
<script src="https://cdn.jsdelivr.net/npm/prismjs/components/prism-javascript.min.js"></script>
<!-- Language support (e.g., JavaScript) -->
<script src="https://cdn.jsdelivr.net/npm/prismjs/components/prism-javascript.min.js"></script>

<!-- Line numbers plugin -->
<link href="https://cdn.jsdelivr.net/npm/prismjs/plugins/line-numbers/prism-line-numbers.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/prismjs/plugins/line-numbers/prism-line-numbers.min.js"></script>

<h1 style="color: green; text-align: center;">🖥️ Fundamentals of Programming (CS-114)</h1>
<br><br>
<h1 style="color: blue; text-align: center;">📝 Introduction to Computer Programming and Python</h1>
<br><br>
<h1 style="color: red; text-align: center;">🎓 Dr. Aamir Alaud Din</h1>
<br><br>
<h1 style="color: green; text-align: center;">🗓️ August 14, 2025</h1>
<br><br>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0; padding-left: 10px;">Contents</h2>
<div style="font-weight: bold; font-size: 24px; line-height: 2.0; padding-left: 40px;">
  <ol type="1">
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>Computers and Computations</li>
    <li>Human Computer Interaction</li>
    <li>Python Programming</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>



<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">1. Objectives</h2>
<p style="line-height: 2.0; text-align: justify;">After <span style="color: green;">taking this lecture</span> and <span style="color: red;">studying</span>, you should be able to:</p>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Describe computers and their use for computations in your own words.</li>
    <li>Explain human computer interaction in your own words.</li>
    <li>Describe the scope and importance of Python programming language.</li>
  </ul>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">2. The Why Section</h2>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>When we use computers for computation, we provide formulas to computers.</li>
    <li>We can also perform computations on paper using the formulas.</li>
    <li><span style="color: blue;">One reason of studying this topic is to know if a computation can be performed by hand, then why do we use computers.</span></li>
    <li>Computers know only binary language (0's and 1's only) which human can't understand.</li>
    <li><span style="color: blue;">Second reasons of studying this topic is to know how human computer interaction occurs despite of lacking the knowledge of binary language.</span></li>
    <li>There are many other scientific programming languages like MATLAB, Octave, Scilab, Julia, Fortran, Mathematica, and Maple etc.</li>
    <li>Python is not a scientific programming language, but a general purpose programming language.</li>
    <li><span style="color: blue;">The third reason of studying this topic is to know why we are studying Python for scientific computing despite of the availability of many scientific programming languages.</span></li>
  </ul>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">3. Computers and Computations</h2>
<style>
.definition-box {
width: 100%;
border: 2px solid navy;
border-radius: 5px;
overflow: hidden;
}
.definition-header {
background-color: navy;
color: white;
padding: 10px;
font-weight: bold;
}
.definition-body {
background-color: white;
color: navy;
padding: 15px;
line-height: 2.0;
text-align: justify;
}
</style>

<div class="definition-box">
  <div class="definition-header">Definition: Computer</div>
  <div class="definition-body">
    A computer is a universal machine that can do any computation you want it to do.
    <br><div style="text-align: right;">&mdash; Dr. Richard Stallman &mdash;</div>
  </div>
</div>
<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0101.png" width="100%" alt="computer">
  <br><br>
  <figcaption style="text-align: center;"><strong>Figure 1.</strong> A computer with an OS and desktop environment.</figcaption>
</figure><br>

<style>
.line-container {
  position: relative;
  margin-left: 0px; /* spacing from other elements */
  margin-right: 0px;
  margin-top: 20px;
  margin-bottom: 20px;
}
.horizontal-line {
  height: 2px; /* Line thickness */
  background-color: blue; /* Line color */
  width: 100%; /* Full width line */
}
  .top-box {
  width: 10px; /* Box width */
  height: 10px; /* Box height */
  background-color: red; /* Box color */
  position: absolute;
  top: 100%; /* Position just below the line */
  left: 0; /* Align to the left side */
  margin-top: 0px; /* Optional spacing between line and box */
}
.bottom-box {
  width: 10px; /* Box width */
  height: 10px; /* Box height */
  background-color: red; /* Box color */
  position: absolute;
  bottom: 100%; /* Position just below the line */
  right: 0%; /* Align to the left side */
  margin-top: 0px; /* Optional spacing between line and box */
}
</style>

<div class="line-container">
  <div class="horizontal-line"></div>
  <div class="top-box"></div>
</div>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Example 1: Computation</h3>
<p style="line-height: 2.0;">A car is moving with a speed of $120
\; km/h$. How long will it take to cover a distance of $378\;km$ (distance between Islamabad and Lahore)?</p>
<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Solution</h3>
<div style="line-height: 2.0;">
  <ul style="list-style-type:disc">
    <li>This is an example of a computation.</li>
    <li>Any problem involving mathematical operations, at least a binary operation, is a computational problem.</li>
    <li>Such problems can be solved by hand.</li>
    <li>The problem in this example is solved as shown below.</li>
  </ul>
</div>
<style>
  .math-container {
  max-width: 100%;
  overflow-x: auto;
  }
</style>
<script>
  window.MathJax = {
    tex: {
    tags: 'ams'
  },
  options: {
    fleqn: true,
    displayAlign: 'left',
    menuSettings: {
      inTabOrder: false
    }
  },
chtml: {
  linebreaks: {
    automatic: true,
    width: "container"
    }
  },
svg: {
  linebreaks: {
    automatic: true,
    width: "container"
    }
  }
};
</script>
<style>
  mjx-container[jax="CHTML"][display="true"] {
    text-align: left !important;
  }
</style>

<div class="math-container">
  $$
  \begin{aligned}
    v &= 120\;km/h \\
    s &= 378\;km \\
    t &= ?
  \end{aligned}
  $$
</div>

<p style="line-height: 2.0;">We know that</p>

$$
s = vt
$$

<p style="line-height: 2.0;">Therefore, we have</p>

$$
t = \frac{s}{v} = \frac{378\;km}{120\;km/h} = 3.15\;h
$$
<div class="line-container">
<div class="horizontal-line"></div>
<div class="bottom-box"></div>
</div>

<div style="line-height: 2.0;">
  <ul style="list-style-type:disc">
    <li>Possibility of by hand computations</li>
    <li>Why computers?</li>
    <div style="line-height: 2.0;">
      <ol style="1">
        <strong><li>Speed/Efficiency</li></strong>
        <pre><code class="language-python">for i in range(1, 5001):
        print(f"2 x {i:d} = {2*i:d}")</code></pre>
        <strong><li>Complex computations</li></strong>
        <style>
          .math-container {
          max-width: 100%;
          overflow-x: auto;
          overflow-y: hidden;
          }
          mjx-container[jax="CHTML"][display="true"] {
            text-align: left !important;
          }
          html, body {
            margin: 0;
            padding: 0;
            overflow-y: auto; /* allow scroll if needed */
          }
        </style>
        <script>
          window.MathJax = {
            tex: {
            tags: 'ams'
          },
          options: {
            fleqn: true,
            displayAlign: 'left',
            menuSettings: {
              inTabOrder: false
            }
          },
        chtml: {
          linebreaks: {
            automatic: true,
            width: "container"
            }
          },
        svg: {
          linebreaks: {
            automatic: true,
            width: "container"
            }
          }
        };
        </script>
        <div class="math-container">
          $$
          \begin{vmatrix}
             -2 & 7 & 0 & 6 & -2 \\
             1 & -1 & 3 & 2 & 2 \\
             3 & 4 & 0 & 5 & 3 \\
             2 & 5 & 4 & -2 & 2 \\
             0 & 3 & -1 & 1 & -4
          \end{vmatrix}
          $$
        </div>
        <ul style="list-style-type:circle">
          <li>Extremely lenghthy computation</li>
          <li><a href="https://semath.info/src/determinant-five-by-five.html" target="_blank">Click here</a> to see by hand computation</li>
          <li>Very high chances of error</li>
          <pre><code class="language-python">import numpy as np
&nbsp;
a = np.array([[-2, 7, 0, 6, -2],
              [1, -1, 3, 2, 2],
              [3, 4, 0, 5, 3],
              [3, 4, 0, 5, 3],
              [0, 3, -1, 1, -4]])
&nbsp;
print(f'Determinant of given matrix is {np.linalg.det(matrix):.2f}')</code></pre>
          <li>Short programming</li>
          <li>No error</li>
        </ul>   
        <strong><li>Generalization</li></strong>
        <ul style="list-style-type:circle">
      <li>Single program</li>
      <li>Multiple user choices in table of 2</li>
      <ul style="list-style-type:square">
        <li>Any table</li>
        <li>Any start</li>
        <li>Any stop</li>
        <pre><code class="language-python">table = int(input("Enter the required table: "))
start = int(input("Enter the starting point of the table: "))
stop = int(input("Enter the stopping point of the table: "))
for counter in range(start, stop + 1):
print(f'{table:d} x {counter:d} = {table*counter:d}')</code></pre>
      </ul>
      <li>Determinant of any order matrix with same program</li>
    </ul>
      </ol>
    </div>
  </ul>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">4. Human Computer Interaction</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li>Problems</li>
    <ul style="list-style-type:circle">
      <li>Computers &mdash; The most dumb machines in the world</li>
      <li>Computers' language &mdash; Binary language</li>
      <br>
      <figure style="margin: 0 auto; text-align: center;">
        <img src="../images/0102.png" width="100%" alt="binary"><br><br>
        <figcaption style="text-align: center;"><strong>Figure 2.</strong> Example of a binary code.</figcaption>
      </figure><br>
      <li>Computers' reliance &mdash; User's alphanumeric and special character instructions</li>
      <li>A classic example</li>
    </ul>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0103.png" width="100%" alt="com_gap"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 3.</strong> Failure of a business deal due to communication gap.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0104.png" width="100%" alt="success"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 4.</strong> Successful business deal with the help of a translator.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0105.png" width="100%" alt="bin_conf"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 5.</strong> No human computer interaction due to communication gap.</figcaption>
</figure><br>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0106.png" width="100%" alt="sucess_code"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 6.</strong> Human computer interaction with the help of Python interpreter.</figcaption>
</figure><br>

<br>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0107.png" width="60%" alt="python_prog"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 7.</strong> A Python program.</figcaption>
</figure><br>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Figure 7 &mdash; Python program but not Python</li>
    <li>Python?</li>
    <li>Python &mdash; Installed on your laptop/computer</li>
    <li>Python &mdash; conversion of Python code to machine code and vice versa</li>
    <li>Python program &mdash; Human readable and understandable text file</li>
    <li>Python interpreter understands Python programs only & no other programs</li>
    <li>One missing gap left</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0108.png" width="100%" alt="missing_link"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 8.</strong> Complete loop of human computer interaction clarifying the learning of of Python programming.</figcaption>
</figure><br>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">5. Python Programming</h2>
<style>
.definition-box {
width: 100%;
border: 2px solid navy;
border-radius: 5px;
overflow: hidden;
}
.definition-header {
background-color: navy;
color: white;
padding: 10px;
font-weight: bold;
}
.definition-body {
background-color: white;
color: navy;
padding: 15px;
line-height: 2.0;
text-align: justify;
}
</style>

<div class="definition-box">
  <div class="definition-header">Computer Programming</div>
  <div class="definition-body">
    Computer programming is the art of interacting with the computers to instruct the computers to perform a given computation.
  </div>
</div>
<div style="line-height: 2.0; text-align: justify;">
  <ul type="list-style-type:disc">
    <li>Our focus &mdash; scientific computing in science and engineering</li>
    <li>First release 1991 by Guido van Rossum</li>
    <br>
    <figure style="margin: 0 auto; text-align: center;">
      <img src="../images/0109.png" width="70%" alt="rossum"><br><br>
      <figcaption style="text-align: center;"><strong>Figure 9.</strong> Guido van Rossum &mdash; Python developer.</figcaption>
    </figure><br>
    <li>General purpose programming language</li>
    <li>Among top 5 programming languages for the last few years</li>
    <li>Currently, world's most popular programming language <a href="[https://www.](https://www.tiobe.com/tiobe-index/)" target="_blank">click here to see</a></li>
    <br>
    <figure style="margin: 0 auto; text-align: center;">
      <img src="../images/0110.png" width="100%" alt="tiobe"><br><br>
      <figcaption style="text-align: center;"><strong>Figure 10.</strong> Top ten programming languages based on number of hits per day.</figcaption>
    </figure><br>
    <li>Current version &mdash; Python 3.13</li>
    <li>Scope and applications</li>
    <figure style="margin: 0 auto; text-align: center;">
      <img src="../images/0111.png" width="100%" alt="scope"><br><br>
      <figcaption style="text-align: center;"><strong>Figure 11.</strong> Top 10 applications of Python showing its scope.</figcaption>
    </figure><br>
    <li>Python for scientific computing</li>
    <figure style="margin: 0 auto; text-align: center;">
      <img src="../images/0112.png" width="100%" alt="scientific_computing"><br><br>
      <figcaption style="text-align: center;"><strong>Figure 12.</strong> Scientific computing with Python.</figcaption>
    </figure><br>
  </ul>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">6. Summary</h2>
<div style="line-height: 2.0;">
  <ul style="list-style-type:disc">
    <li>Computers, because of their efficiency, performing complex computations, and
generalization of programs are used in scientific computation.</li>
    <li>Computer programming converts human understandable code to machine code for
the computers and machine code to human readable format for user.</li>
    <li>Python program is a collection of instructions in the form of alphanumeric
characters while python is the software installed in your computer to convert python
program to machine code.</li>
    <li>Since machine code is hard to code, so we need to learn python programming and
write instructions for the computers in a python program and hand it over to python
for the rest of the job.</li>
    <li>Python is encompassing the most important parts of data, science, engineering, and
IT, therefore, is an important programming language.</li>
  </ul>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">7. Exercises</h2>
<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Exercise 1</h3>
<p style="line-height: 2.0; text-align: justify;">Write a note on the history of development of Python.</p>
<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Exercise 2</h3>
<p style="line-height: 2.0; text-align: justify;">All the character keys on the keyboard have been assigned an ASCII code which is a number. For example, ASCII code of letter "a" is 97. The 8-bit binary representation of 97 can be found as shown below.</p>

<div style="display: grid; place-items: center; margin-top: 20px;">
  <table id="lecture-table">
    <thead>
      <th>Bit No.</th>
      <th>Power of 2</th>
      <th>Decision</th>
      <th>Use/Don't Use (1/0)</th>
      <th>Remainder</th>
    </thead>
    <tbody>
      <tr>
        <td>$7$</td>
        <td>$2^7=128$</td>
        <td>$128>97$</td>
        <td>$0$</td>
        <td>x</td>
      </tr>
      <tr>
        <td>$6$</td>
        <td>$2^6=64$</td>
        <td>$64 < 97$</td>
        <td>$1$</td>
        <td>$97-64=33$</td>
      </tr>
      <tr>
        <td>$5$</td>
        <td>$2^5=32$</td>
        <td>$32 < 33$</td>
        <td>$1$</td>
        <td>$33-32=1$</td>
      </tr>
      <tr>
        <td>$4$</td>
        <td>$2^4=16$</td>
        <td>$16 > 1$</td>
        <td>$0$</td>
        <td>x</td>
      </tr>
      <tr>
        <td>$3$</td>
        <td>$2^3=8$</td>
        <td>$8 > 1$</td>
        <td>$0$</td>
        <td>x</td>
      </tr>
      <tr>
        <td>$2$</td>
        <td>$2^2=4$</td>
        <td>$4 > 1$</td>
        <td>$0$</td>
        <td>x</td>
      </tr>
      <tr>
        <td>$1$</td>
        <td>$2^1=2$</td>
        <td>$2 > 1$</td>
        <td>$0$</td>
        <td>x</td>
      </tr>
      <tr>
        <td>$0$</td>
        <td>$2^0=1$</td>
        <td>$1 = 1$</td>
        <td>$1$</td>
        <td>$1-1=0$</td>
      </tr>
    </tbody>
  </table>
</div>
<style>
  #lecture-table {
    border-collapse: collapse;
    table-layout: auto;
    width: auto; /* Ensures content-based width */
    margin: 0 auto; /* Fallback centering */
  }
  #lecture-table th, #lecture-table td {
    border: 1px solid #b9b9b9;
    padding: 8px 12px;
    white-space: nowrap;
  }
  #lecture-table thead {
    background-color: #cfcfcf;
  }
  #lecture-table tbody tr:nth-child(even) {
    background-color: #dddddd;
  }
  #lecture-table tbody tr:nth-child(odd) {
    background-color: #ffffff;
  }
</style>

<p style="line-height: 2.0; text-align: justify;">So, the 8-bit binary representation of 97 using $4$<sup>th</sup> column is $01100001$. Use this procedure to write your first and last name separated by space. Also use binary code of space.</p>

<h3 style="color: red; font-weight: bold; line-height: 2.0;">Homework No. 1</h3>
<span style="color: red;">
  <div style="line-height: 2.0; text-align: justify;">
    <ul style="list-style-type:disc">
      <li>Exercise 2 is your homework.</li>
      <li>The deadline of submission is next week the same day.</li>
      <li>Submission after class time will lead to deduction of 50% marks.</li>
      <li>Submission after 24 hours of deadline will be considered no submission.</li>
    </ul>
  </div>
</span>