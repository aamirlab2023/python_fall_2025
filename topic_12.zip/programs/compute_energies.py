import energy_project as ep

mass = 3
heights = [2.0, 2.3, 4.0, 4.1, 4.7, 3.2]
velocity = 50

ep.header()

counter = 1
for height in heights:
    k, p, t = ep.energies(mass, height, velocity)
    print(f"{counter:<10d}{height:<14.2f}{k:<22.4f}{p:<24.4f}{t:<.4f}")
    counter += 1
