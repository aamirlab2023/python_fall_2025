def header():
    print("S. No.    Height (m)    Kinetic Energy (J)    Potential Energy (J)    Total Energy (J)")
    print("======    ==========    ==================    ====================    ================")

def energies(mass, height, velocity):
    ke = 1/2*mass*velocity**2
    pe = mass*9.8*height
    te = ke + pe
    return ke, pe, te
