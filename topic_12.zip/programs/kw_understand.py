def energies(mass, height, velocity, g_acc=9.8, tot_en=True):
    ke = 1/2*mass*velocity**2
    pe = mass*g_acc*height
    if tot_en == False:
        return ke, pe
    else:
        te = ke + pe
        return ke, pe, te

k, p = energies(2.0, 1.5, 1.5, tot_en=False)
print(f"Kinetic Energy: {k:.2f}")
print(f"Potential Energy: {p:.2f}")