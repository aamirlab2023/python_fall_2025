def gen_table(r, c):
    print("<div style=\"display: grid; place-items: center; ", end="")
    print("margin-top: 20px;\">")
    print("  <table id=\"lecture-table\">")
    print("    <thead>")
    for i in range(c):
        print("      <th></th>")
    print("    </thead>")
    print("    <tbody>")
    for i in range(r):
        print("      <tr>")
        for j in range(c):
            print("        <td></td>")
        print("      </tr>")
    print("    </tbody>")
    print("  </table>")
    print("</div>")

gen_table(25, 5)