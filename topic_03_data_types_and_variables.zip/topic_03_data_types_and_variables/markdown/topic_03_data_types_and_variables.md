<link href="https://cdn.jsdelivr.net/npm/prismjs/themes/prism.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/prismjs/prism.js"></script>
<script src="https://cdn.jsdelivr.net/npm/prismjs/components/prism-javascript.min.js"></script>
<!-- Language support (e.g., JavaScript) -->
<script src="https://cdn.jsdelivr.net/npm/prismjs/components/prism-javascript.min.js"></script>

<!-- Line numbers plugin -->
<link href="https://cdn.jsdelivr.net/npm/prismjs/plugins/line-numbers/prism-line-numbers.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/prismjs/plugins/line-numbers/prism-line-numbers.min.js"></script>

<h1 style="color: green; text-align: center; line-height: 2.0;">🖥️ Fundamentals of Programming (CS-114)</h1>
<br>
<h1 style="color: blue; text-align: center; line-height: 2.0;">📝 Introduction to Data Types and Variables</h1>
<br>
<h1 style="color: red; text-align: center; line-height: 2.0;">🎓 Dr. Aamir Alaud Din</h1>
<br>
<h1 style="color: green; text-align: center; line-height: 2.0;">🗓️ August 22, 2025</h1>
<br>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0; padding-left: 10px;">Contents</h2>
<div style="font-size: 24px; font-weight: bold; line-height: 2.0; padding-left: 40px;">
  <ol type="1">
    <li style="color: red;">Add introduction to python functions here and also add in the why section.</li>
    <li>Recap</li>
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>Data Tyes</li>
    <li>Variables</li>
    <li>Assignment Operator</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0; padding-left: 10px;">1. Recap</h2>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li style="color: red;">Add introduction to python functions here and also add in the why section.</li>
    <li>Python is a free programming language licensed under PSF which can be downloaded, distributed, installed, and used free (libre).</li>
    <li>Python packages are released by PyPI.</li>
    <li>Anaconda provides python with several packages incorporated which is very useful specially for the newbies.</li>
    <li>Python has different working environments including interactive mode, text and terminal, and IDE arrangements.</li>
    <li>The installer provided by Anaconda and Spyder IDE (because it has MATLAB like layout as well) and Visual Studio Code are highly recommended for scientific computing.</li>
  </ul>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">2. Objectives</h2>
<p style="line-height: 2.0; text-align: justify;">After <span style="color: green;">taking this lecture</span> and <span style="color: red;">studying</span>, you should be able to:</p>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li style="color: red;">Add introduction to python functions here and also add in the why section.</li>
    <li>Describe in your own words different data types in human communication.</li>
    <li>Describe different data types in python in general and numeric data types in particular in python, in your own words.</li>
    <li>Describe in you own words the variables and the rules for naming variables.</li>
    <li>Use <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">print</code> function to print data types and variables.</li>
  </ul>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">3. The Why Section</h2>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li style="color: red;">Add introduction to python functions here and also add in the why section.</li>
    <li>When we communicate in the form of reading, writing, and speaking, we use data in the form of text and numbers.</li>
    <li>Do programming languages in general and Python in particular have data types?</li>
    <li>If yes, what are these data types and why are they used in computer programming?</li>
    <li>One of the reasons for studying this topic is to know which data types there are in Python and why they used in Python.</li>
    <li>If we have to use a bunch of numbers in a program, can we assign these numbers to different variables just like in Physics we use</li>
    <style>
      .math-container {
      max-width: 100%;
      overflow-x: auto;
      }
      mjx-container[jax="CHTML"][display="true"] {
        text-align: left !important;
      }
      html, body {
        margin: 0;
        padding: 0;
        overflow-y: auto; /* allow scroll if needed */
      }
    </style>
    <script>
      window.MathJax = {
        tex: {
        tags: 'ams'
      },
      options: {
        fleqn: true,
        displayAlign: 'left',
        menuSettings: {
          inTabOrder: false
        }
      },
    chtml: {
      linebreaks: {
        automatic: true,
        width: "container"
        }
      },
    svg: {
      linebreaks: {
        automatic: true,
        width: "container"
        }
      }
    };
    </script>
    <style>
      mjx-container[jax="CHTML"][display="true"] {
        text-align: left !important;
      }
    </style>
    <div class="math-container">
      $$
      \begin{aligned}
        u &= 10\;m/s \\
        t &= 50\;s
      \end{aligned}
      $$
    </div>
    <li>If yes, are there special rules for naming variables and what are these rules?</li>
    <li>The second reason for studying this topic is to know the valid variable names to which the data can be assigned.</li>
    <li>If we assign a number to a variable, can we check that the data assigned is correct?</li>
    <li>If yes, how can we check whether the data has been assigned correctly?</li>
    <li>The last point to know through this topic is to study how to see the output data on the standard output display device (LCD display)?</li>
    <li>After all, we have to take decision after knowing (seeing) the output of a computation, for example, action taken by the docotr after seeing the body temperature of a patient on the display of a digital thermometer?</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0301.png" width="60%" alt="thermometer"><br><br>
  <figcaption style="text-align: center;"><strong>Figure 1.</strong> Digital thermometer with a display.</figcaption>
</figure><br>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">4. Data Types</h2>
<div style="line-height: 2.0; text-align: justify;">
  <ul type="list-style-type:disc">
    <li>Purchase of ice cream soda under brand name of Pakola</li>
    <figure style="margin: 0 auto; text-align: center;">
      <img src="../images/0302.png" width="100%" alt="Pakola"><br><br>
      <figcaption style="text-align: center;"><strong>Figure 2.</strong> Cans and bottle of Pakola ice cream soda.</figcaption>
    </figure><br>
    <li>Purchasing of cans</li>
    <li>Purchasing of a bottle</li>
    <li>Fundamentals of Programming class</li>
    <li>Number of students in the class</li>
    <li>Height of a student in the class</li>
    <li>Attribute to which number of cans and students are linked &mdash; whole numbers</li>
    <li>Attribute to which quantity in the bottle and height of student are linked &mdash; decimal point numbers</li>
    <li>In the sentence, "<span style="color: green;">Give me </span><span style="color: orange;">12 </span><span style="color: green;">cans and a </span><span style="color: red;">2.25 </span><span style="color: green;">L bottle of Pakola ice cream soda.</span>"</li>
    <ul style="list-style-type:circle">
      <li>12 is number data type</li>
      <li>2.25 is also number data type</li>
      <li>Everything else is text data type</li>
    </ul>
    <li>In our daily life communication, we understand sentences based on data types.</li>
    <li>In subconscious</li>
    <ul style="list-style-type:circle">
      <li>12 for counting</li>
      <li>2.25 for measurement</li>
    </ul>
    <li>Data types in programming languages C, C++, Java, Julia, MATLAB etc.</li>
    <li>Data types in Python</li>
    <figure style="margin: 0 auto; text-align: center;">
      <img src="../images/0303.png" width="100%" alt="data"><br><br>
      <figcaption style="text-align: center;"><strong>Figure 3.</strong> Data types in Python programming language used in scientific computing.</figcaption>
    </figure><br>
    <li>The binary and set data types &mdash; computer science use</li>
    <li>Python function <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">type</code> is used to check data type</li>
    <li>Short description of data types is below</li>
    <li style="color: red;">Add introduction to python functions here and also add in the why section.</li>
  </ul>
</div>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">1. Numeric Data Type</h3>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">a) Integer</h4>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Counting</li>
    <li>Binary operations valid</li>
    <li>Python representation <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">int</code></li>
  </ul>
</div>

<pre><code class="language-python">>>> type(2)
&lt;class 'int'&gt;</code></pre>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">b) Float</h4>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Measurement</li>
    <li>Binary operations valid</li>
    <li>Python representation <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">float</code></li>
  </ul>
</div>

<pre><code class="language-python">>>> type(2.5)
&lt;class 'float'&gt;</code></pre>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">c) Complex</h4>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Imaginary measurements</li>
    <li>Binary operations valid</li>
    <li>Python representation <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">complex</code></li>
  </ul>
</div>

<pre><code class="language-python">>>> type("2+3j")
&lt;class 'complex'&gt;</code></pre>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">2. Sequence Data Type</h3>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">a) String</h4>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Text must be enclosed within single or double quotes</li>
    <li>Binary operations invalid mathematically</li>
    <li>The <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">+</code> and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">*</code> operations are valid but not in mathematical sense</li>
    <li>Python representation <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">str</code></li>
  </ul>
</div>
<pre><code class="language-python">>>> type("Aamir")
&lt;class 'str'&gt;</code></pre>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">b) List</h4>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Mutable collection of items</li>
    <li>Binary operations valid on numeric items</li>
    <li>Python representation <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">list</code></li>
  </ul>
</div>
<pre><code class="language-python">>>> type([1, 2, 3])
&lt;class 'list'&gt;</code></pre>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">c) Tuple</h4>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Immutable collection of items</li>
    <li>Binary operations valid on numeric items</li>
    <li>Python representation <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">tuple</code></li>
  </ul>
</div>
<pre><code class="language-python">>>> type((1, 2, 3))
&lt;class 'tuple'&gt;</code></pre>

<h4 style="color: blue; font-weight: bold; line-height: 2.0;">d) Sequence</h4>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Immutable sequence of integers</li>
    <li>Binary operations valid on sequence items</li>
    <li>Python representation <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">range</code></li>
  </ul>
</div>
<pre><code class="language-python">>>> type(range(5))
&lt;class 'range'&gt;</code></pre>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">3. Dictionary</h3>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Unordered collection of key-value pairs</li>
    <li>Keys are unique and immutable</li>
    <li>Values can be of any type</li>
    <li>Python representation <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">dict</code></li>
  </ul>
</div>

<pre><code class="language-python">>>> type({'Name': 'Aamir'})
&lt;class 'dict'&gt;</code></pre>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">4. Boolean</h3>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Data type with two values only i.e., <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">True</code> and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">False</code></li>
    <li>Outputs the comparison of statements</li>
    <li>Python representation <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">bool</code></li>
  </ul>
</div>

<pre><code class="language-python">>>> type(5 > 4)
&lt;class 'bool'&gt;</code></pre>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">5. None</h3>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Singleton object represents absence of value</li>
    <li>Signifies no result, value, or data</li>
    <li>Python representation <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">NoneType</code></li>
  </ul>
</div>

<pre><code class="language-python">>>> type(None)
&lt;class 'NoneType'&gt;</code></pre>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">5. Variables</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li>Physics example revisited</li>
  </ul>
</div>

<style>
.line-container {
  position: relative;
  margin-left: 0px; /* spacing from other elements */
  margin-right: 0px;
  margin-top: 20px;
  margin-bottom: 20px;
}

.horizontal-line {
  height: 2px; /* Line thickness */
  background-color: blue; /* Line color */
  width: 100%; /* Full width line */
}

  .top-box {
  width: 10px; /* Box width */
  height: 10px; /* Box height */
  background-color: red; /* Box color */
  position: absolute;
  top: 100%; /* Position just below the line */
  left: 0; /* Align to the left side */
  margin-top: 0px; /* Optional spacing between line and box */
}

.bottom-box {
  width: 10px; /* Box width */
  height: 10px; /* Box height */
  background-color: red; /* Box color */
  position: absolute;
  bottom: 100%; /* Position just below the line */
  right: 0%; /* Align to the left side */
  margin-top: 0px; /* Optional spacing between line and box */
}
</style>

<div class="line-container">
  <div class="horizontal-line"></div>
  <div class="top-box"></div>
</div>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Example 1: Assigning Variable</h3>

<p style="line-height: 2.0; text-align: justify;">An object falls from a height of $25\;m$. What will be its velocity just before hitting the ground?</p>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Solution</h3>
<p style="line-height: 2.0; text-align: justify;">First we assign the data to variables and then use the governing equation $v^2 - u^2 = 2gh$</p>
<style>
  .math-container {
  max-width: 100%;
  overflow-x: auto;
  }
  mjx-container[jax="CHTML"][display="true"] {
    text-align: left !important;
  }
  html, body {
    margin: 0;
    padding: 0;
    overflow-y: auto; /* allow scroll if needed */
  }
</style>
<script>
  window.MathJax = {
    tex: {
    tags: 'ams'
  },
  options: {
    fleqn: true,
    displayAlign: 'left',
    menuSettings: {
      inTabOrder: false
    }
  },
chtml: {
  linebreaks: {
    automatic: true,
    width: "container"
    }
  },
svg: {
  linebreaks: {
    automatic: true,
    width: "container"
    }
  }
};
</script>
<style>
  mjx-container[jax="CHTML"][display="true"] {
    text-align: left !important;
  }
</style>
<div class="math-container">
  $$
  \begin{flalign}
    &u =  0& \\
    &g = 9.8\;m/s^2& \\
    &h = 25\;m& \\
    &v^2 - u^2 = 2gh& \\
    &v^2 - 0^2 = 2 \times 9.8 \times 25& \\
    &v = \sqrt{2 \times 9.8 \times 25} = 22.14\;m/s& \\
  \end{flalign}
  $$
</div>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="bottom-box"></div>
</div>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>No direct use of numbers</li>
    <li>Numerics assigned to variables</li>
    <li>Same in Python</li>
  </ul>
</div>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Rules for Naming Variables</h3>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Python has following rules for naming variables</li>
    <ul style="list-style-type:circle">
      <li>A variable name must begin with an alphabet (A-Z, a-z) or an underscore (_).</li>
      <li>A variable name cannot start with a digit.</li>
      <ul style="list-style-type:square">
        <li><strong>Legal: </strong><code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">my_variable</code>, <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">_temp</code>, and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">name</code></li>
        <li><strong>Illegal: </strong><code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">1st_variable</code> and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">9lives</code></li>
      </ul>
      <li>Variable names can only contain alphanumeric characters (A-Z, a-z, 0-9) and underscores (_). </li>
      <ul style="list-style-type:square">
        <li><strong>Legal: </strong><code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">user_id</code>, <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">data2025</code>, and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">_private_data</code></li>
        <li><strong>Illegal: </strong><code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">my-variable</code>, <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">user@email.com</code>, and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">total$</code></li>
      </ul>
      <li>Python variable names are case-sensitive.</li>
      <ul style="list-style-type:square">
        <li><code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">Aamir</code>, <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">aamir</code>, <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">AAMIR</code> are different names.</li>
      </ul>
      <li>Variable names cannot contain spaces. Use underscores (_) to separate words in multi-word variable names (snake_case is the common convention).</li>
      <ul style="list-style-type:square">
        <li><strong>Legal: </strong><code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">first_name</code> and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">total_amount</code></li>
        <li><strong>Illegal: </strong><code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">first name</code> and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">total amount</code></li>
      </ul>
      <li>Do not use Python's reserved keywords as variable names because these words have special meaning in Python.</li>
      <ul style="list-style-type:square">
        <li><code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">if</code>, <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">else</code>, <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">while</code>, and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">class</code> etc.</li>
      </ul>
      <li>While not strictly forbidden, it is generally advised to avoid using names of built-in functions to prevent shadowing or unexpected behavior.</li>
      <ul style="list-style-type:square">
        <li><code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">list</code>, <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">str</code>, and <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">type</code>etc.</li>
      </ul>
      <li>Although not a strict rule enforced by the interpreter, it is a strong convention to choose variable names that are descriptive and clearly indicate their purpose, making the code more readable and maintainable.</li>
    </ul>
  </ul>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">6. Assignment Operator</h2>
<div style="line-height: 2.0;">
  <ul type="list-style-type:disc">
    <li>From example 1</li>
    <pre><code class="language-python">init_vel = 0
grav_acc = 9.8
height = 25</code></pre>
    <li>Any name but as per the rules e.g.,</li>
    <pre><code class="language-python">i_vel = 0
g_acc = 9.8
hght = 25</code></pre>
    <li>The operator <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">=</code> not an equal to symbol</li>
    <li>It is assignment operator</li>
    <li>Assigns whatever is on right side to the variable on left</li>
    <li>Mathematically invalid equations</li>
    <style>
      .math-container {
      max-width: 100%;
      overflow-x: auto;
      }
      mjx-container[jax="CHTML"][display="true"] {
        text-align: left !important;
      }
      html, body {
        margin: 0;
        padding: 0;
        overflow-y: auto; /* allow scroll if needed */
      }
    </style>
    <script>
      window.MathJax = {
        tex: {
        tags: 'ams'
      },
      options: {
        fleqn: true,
        displayAlign: 'left',
        menuSettings: {
          inTabOrder: false
        }
      },
    chtml: {
      linebreaks: {
        automatic: true,
        width: "container"
        }
      },
    svg: {
      linebreaks: {
        automatic: true,
        width: "container"
        }
      }
    };
    </script>
    <style>
      mjx-container[jax="CHTML"][display="true"] {
        text-align: left !important;
      }
    </style>
    <div class="math-container">
      $$
      \begin{aligned}
        &x = 5& \\
        &x = x+2&
      \end{aligned}
      $$
    </div>
    <li>Following program is correct</li>
  </ul>
</div>

```python
x = 5
x = x + 2
```

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Printing Variables</h3>

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Python's built-in function <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">print</code></li>
    <li>Printing of variables</li>
  </ul>
</div>

```python
bond_len = 1.4
n_bonds = 12
molecule = 'Benzene'
print(bond_len)
print(n_bonds)
print(molecule)
```

<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Output is below</li>
  </ul>
</div>

<pre style="background-color: #f5f2f0; padding-left: 15px; padding-top: 10px; padding-bottom: 10px; padding-right: 15px;"><code>1.4
12
Benzene</code></pre>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">7. Summary</h2>
<div style="line-height: 2.0; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Just like the data types in daily life, Python also has different data types.</li>
    <li>The classification of data types is</li>
    <ul style="list-style-type:circle">
      <li>Numeric</li>
      <ul style="list-style-type:square">
        <li>Integer: counting</li>
        <li>Float: measurement</li>
        <li>Complex: imaginary numbers</li>
      </ul>
      <li>Sequence</li>
      <ul style="list-style-type:square">
        <li>String: text</li>
        <li>List: mutable collection of items</li>
        <li>Tuple: immutable collection of items</li>
        <li>Range: immutable sequence of integers</li>
      </ul>
      <li>Dictionary: key-value pairs</li>
      <li>Boolean: True and False</li>
      <li>None: No data</li>
    </ul>
    <li>Arithmetic operations are valid on numeric data types.</li>
    <li>Variables are used to assign data to and for use in the program.</li>
    <li>Rules for naming variables must be followed.</li>
    <li>Assignment operator assigns the computation or values on right hand side of assignment operator to the variable on the left hand side.</li>
    <li>Any data type can be assigned to a valid variable name.</li>
  </ul>
</div>

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 5px; line-height: 2.0; padding-left: 10px;">8. Exercises</h2>
<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Exercise 1</h3>
<p style="line-height: 2.0; text-align: justify;">Identify the following data types</p>
<div style="line-height: 2.0;">
  <ol type="a">
    <li>-23</li>
    <li>78</li>
    <li>23.5</li>
    <li>3 - 2j</li>
    <li>-27.5</li>
    <li>7.02E+03</li>
    <li>-1.235E-12</li>
    <li>2 + 7.5 j</li>
  </ol>
</div>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Exercise 2</h3>
<p style="line-height: 2.0; text-align: justify;">Avogadro's number is the number of particles which is a count and not a measurement. In a Python statement shown below</p>

```python
avogadro_n = 6.022E+23
```

<p style="line-height: 2.0; text-align: justify;">Does the Python interpreter recognizes <code style="background-color: #f5f2f0; padding: 2px 4px; border-radius: 4px; font-family: monospace;">avogadro_n</code> as integer or float? Comment on your understanding?</p>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Exercise 3</h3>
<p style="line-height: 2.0; text-align: justify;">Assign the data in exercise 1 to valid variable names and print them.</p>

<h3 style="color: blue; font-weight: bold; line-height: 2.0;">Exercise 4</h3>
<p style="line-height: 2.0; text-align: justify;">Which of the following variable names are valid or invalid. Give reason of invalidity if the variable name is invalid.</p>

<div style="line-height: 2.0;">
  <ol type="a">
    <li>student name</li>
    <li>MAX_LIMIT</li>
    <li>2students</li>
    <li>count1</li>
    <li>@value</li>
    <li>class</li>
    <li>_hidden_value</li>
    <li>age</li>
    <li>100%done</li>
    <li>Temperature</li>
    <li>salary_2025</li>
    <li>try</li>
    <li>student_name</li>
    <li>is_valid</li>
    <li>total-sum</li>
  </ol>
</div>
